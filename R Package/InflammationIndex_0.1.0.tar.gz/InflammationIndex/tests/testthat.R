library(testthat)
library(InflammationIndex)

test_check("InflammationIndex")
