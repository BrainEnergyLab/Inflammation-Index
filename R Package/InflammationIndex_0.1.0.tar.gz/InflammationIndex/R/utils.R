#' InflammationIndex: A package for analysing microglial morphology
#' 
#' @docType package
#' @name InflammationIndex
#' @import data.table
NULL

usethis::use_package('data.table')
#usethis::use_testthat()