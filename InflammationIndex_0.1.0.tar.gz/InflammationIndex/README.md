# Inflammation-Index
This is the repo for the code used to construct the Inflammation Index, developed by Devin Clarke in Catherine Hall's lab.

## Creating and Using an Inflammation Index

Markdown document describing the pipeline that should be used in combination with this repo to create and use the inflammation index.

## R Folder

Contains the functions that are part of the InflammationIndex R package

## man Folder

Contains the help files for the functions in the InflammationIndex R package

**Note: Add example data, as well as the exact inputs used and an example R script, to show how to use the repo practically**
